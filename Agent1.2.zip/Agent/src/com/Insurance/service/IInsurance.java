package com.Insurance.service;

import java.sql.SQLException;


import com.Insurance.bean.InsuranceClaimBean;
import com.Insurance.exception.InsuranceClaimException;

public interface IInsurance {

	boolean validateDetails(InsuranceClaimBean claimBean) throws InsuranceClaimException;

	InsuranceClaimBean getPolicy_Number(InsuranceClaimBean claimBean) throws SQLException, InsuranceClaimException;



}
