package com.Insurance.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.Insurance.bean.InsuranceClaimBean;
import com.Insurance.dao.InsuranceDao;
import com.Insurance.dao.InsuranceDaoImpl;
import com.Insurance.exception.InsuranceClaimException;

public class InsuranceImpl implements IInsurance {
	InsuranceDao dao=null;
	
	InsuranceClaimBean claimBean1=new InsuranceClaimBean();
	@Override
	public boolean validateDetails(InsuranceClaimBean claimBean) throws InsuranceClaimException {
		List<String> list = new ArrayList<>();
		
		boolean result = true;

		if (!isNumberValid(claimBean.getClaim_Number())) {
			
			list.add("Claim Number should be greater that 0");
		}
		if (!isReasonValid(claimBean.getClaim_Reason())) {
			list.add("claim reason should be valid");
		}
		if (!isAccidentLocationValid(claimBean.getAccident_Location())) {
			list.add("Location should be valid without numerics");
		}
		if (!isAccidentCityValid(claimBean.getAccident_City())) {
			list.add("city should be valid without numerics");
		}
		if (!isAccidentStateValid(claimBean.getAccident_State())) {
			list.add("state should be valid without numerics");
		}
		if (!isAccidentZipValid(claimBean.getAccident_Zip())) {
			list.add("Enter valid ZIP Code");
		}
		if (!isClaimTypeValid(claimBean.getClaim_Type())) {
			list.add("enter valid claim type");
		}
		if (!isPolicyNumberValid(claimBean.getPolicy_Number())) {
			list.add("policy number should be greater than 0");
		}
		if (!list.isEmpty()) {
			
			System.out.println("Errors"+list);
			result=false;
		}
		
		return result;
	}

	private boolean isPolicyNumberValid(int policy_Number) {
		
		return policy_Number>0;
	}

	private boolean isClaimTypeValid(String claim_Type) {
		String RegEx = "[a-z]{3,20}";
		Pattern pattern = Pattern.compile(RegEx);
		
		Matcher matcher = pattern.matcher(claim_Type);
		return matcher.matches();
	}

	private boolean isAccidentZipValid(long accident_Zip) {

		return accident_Zip>0;
	}

	private boolean isAccidentStateValid(String accident_State) {
		String RegEx = "[a-z]{3,20}";
		Pattern pattern = Pattern.compile(RegEx);
		Matcher matcher = pattern.matcher(accident_State);
		return matcher.matches();	
		}

	private boolean isAccidentCityValid(String accident_City) {
		String RegEx = "[a-z]{3,20}";
		Pattern pattern = Pattern.compile(RegEx);
		Matcher matcher = pattern.matcher(accident_City);
		return matcher.matches();
	}

	private boolean isAccidentLocationValid(String accident_Location) {
		String RegEx = "[a-z]{3,20}";
		Pattern pattern = Pattern.compile(RegEx);
		Matcher matcher = pattern.matcher(accident_Location);
		return matcher.matches();
	}

	private boolean isReasonValid(String claim_Reason) {
		String RegEx = "[a-z]{3,20}";
		Pattern pattern = Pattern.compile(RegEx);
		Matcher matcher = pattern.matcher(claim_Reason);
		return matcher.matches();
	}

	private boolean isNumberValid(int claim_Number) {
		
		return claim_Number>0;
	}

	@Override
	public InsuranceClaimBean getPolicy_Number(InsuranceClaimBean claimBean) throws SQLException, InsuranceClaimException {
		
		dao=new InsuranceDaoImpl();
		
		return dao.getPolicy_Number(claimBean);
	}


}
