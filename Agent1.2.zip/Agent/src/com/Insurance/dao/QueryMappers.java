package com.Insurance.dao;

public interface QueryMappers {
	public static final String insertQuery="insert into claim values(?,?,?,?,?,?,?,?)";
	public static final String getpolicy_number="select  POLICY_NUMBER from claim";
}
