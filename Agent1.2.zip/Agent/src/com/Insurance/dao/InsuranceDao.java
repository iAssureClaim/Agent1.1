package com.Insurance.dao;

import java.io.IOException;
import java.sql.SQLException;


import com.Insurance.bean.InsuranceClaimBean;
import com.Insurance.exception.InsuranceClaimException;

public interface InsuranceDao {
	InsuranceClaimBean getPolicy_Number(InsuranceClaimBean insuranceClaimBean) throws SQLException, InsuranceClaimException;
}
