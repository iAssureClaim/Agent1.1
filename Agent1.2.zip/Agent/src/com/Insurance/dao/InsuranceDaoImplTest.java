package com.Insurance.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class InsuranceDaoImplTest {

	@Test
	public void testGetPolicy_Number() {
		
	}

}
