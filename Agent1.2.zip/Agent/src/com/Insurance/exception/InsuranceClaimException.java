package com.Insurance.exception;

public class InsuranceClaimException extends Exception {

	public InsuranceClaimException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
