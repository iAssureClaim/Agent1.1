package com.Insurance.client;

import java.sql.SQLException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.Insurance.bean.InsuranceClaimBean;
import com.Insurance.exception.InsuranceClaimException;
import com.Insurance.service.IInsurance;
import com.Insurance.service.InsuranceImpl;

public class InsuranceMain {
	static Scanner sc=new Scanner(System.in);
	
	static IInsurance service=null;
	static Logger logger = Logger.getLogger(InsuranceMain.class);
public static void main(String[] args) throws SQLException {
	
	PropertyConfigurator.configure("resources/log4j.properties");
	logger.info("log4j file loaded...");
	logger.info("inside main method");
	
	
	InsuranceClaimBean claimBean=new InsuranceClaimBean();
	while(true) {
	System.out.println("Enter the Claim Number");
	claimBean.setClaim_Number(sc.nextInt());
	System.out.println("Enter claim Reason");
	claimBean.setClaim_Reason(sc.next());
	System.out.println("Enter Accident Location");
	claimBean.setAccident_Location(sc.next());
	System.out.println("Enter Accident City");
	claimBean.setAccident_City(sc.next());
	System.out.println("Enter Accident State");
	claimBean.setAccident_State(sc.next());
	System.out.println("Enter Accident Zip");
	claimBean.setAccident_Zip(sc.nextLong());
	System.out.println("Enter Claim Type");
	claimBean.setClaim_Type(sc.next());
	System.out.println("Enter Policy Number");
	claimBean.setPolicy_Number(sc.nextInt());
	
	service=new InsuranceImpl();
		try {
			
				boolean a=service.validateDetails(claimBean);
				if(a==true)
				{
				claimBean=service.getPolicy_Number(claimBean);
				}
				System.out.println("data inserted successfully");
		} catch (InsuranceClaimException e) {
			
			e.printStackTrace();
		}
		
	
	}
}
}
